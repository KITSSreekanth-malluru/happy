/**
 * TelForm.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.castorama.sponkey;

public interface TelForm extends javax.xml.rpc.Service {
    public java.lang.String getTelFormSoapAddress();

    public com.castorama.sponkey.TelFormSoap_PortType getTelFormSoap() throws javax.xml.rpc.ServiceException;

    public com.castorama.sponkey.TelFormSoap_PortType getTelFormSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getTelFormSoap12Address();

    public com.castorama.sponkey.TelFormSoap_PortType getTelFormSoap12() throws javax.xml.rpc.ServiceException;

    public com.castorama.sponkey.TelFormSoap_PortType getTelFormSoap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
