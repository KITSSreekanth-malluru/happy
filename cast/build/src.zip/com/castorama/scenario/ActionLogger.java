package com.castorama.scenario;

import atg.nucleus.GenericService;

public class ActionLogger extends GenericService {

}
