package com.castorama.integration.webservice;

/**
 * @author EPAM team
 */
public interface LogService<T> {

    public void log(T logMessage);

}
