package com.castorama.integration.webservice.inventory.model;

/**
 * @author EPAM team
 */
public class WebServiceConstants {

    public static final String DATE_FORMAT = "yyyy-MM-dd_HH:mm:ss";
}
