package com.castorama.integration.xml;

public class DoneException extends Exception {
	public DoneException() {
		super("all items extracted");
	}
}
