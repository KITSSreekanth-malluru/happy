package com.castorama.integration.bazaarvoice;

class Const {

	/**
	 * 
	 */
	public static final String PRODUCT_ID_PREFIX= "p";

	/**
	 * 
	 */
	public static final String DOCUMENT_ID_PREFIX= "d";

}
