/**
 * LoginUserSEI.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Nov 19, 2006 (02:31:34 GMT+00:00) WSDL2Java emitter.
 */

package com.atg.www.webservices;

public interface LoginUserSEI extends java.rmi.Remote {
    public java.lang.String loginUser(java.lang.String requestXML) throws java.rmi.RemoteException, com.atg.www.atg_security.SecurityException;
}
