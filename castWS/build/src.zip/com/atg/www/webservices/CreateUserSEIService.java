/**
 * CreateUserSEIService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Nov 19, 2006 (02:31:34 GMT+00:00) WSDL2Java emitter.
 */

package com.atg.www.webservices;

public interface CreateUserSEIService extends javax.xml.rpc.Service {
    public java.lang.String getCreateUserSEIPortAddress();

    public com.atg.www.webservices.CreateUserSEI getCreateUserSEIPort() throws javax.xml.rpc.ServiceException;

    public com.atg.www.webservices.CreateUserSEI getCreateUserSEIPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
