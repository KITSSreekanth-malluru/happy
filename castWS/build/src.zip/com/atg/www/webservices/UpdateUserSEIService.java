/**
 * UpdateUserSEIService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Nov 19, 2006 (02:31:34 GMT+00:00) WSDL2Java emitter.
 */

package com.atg.www.webservices;

public interface UpdateUserSEIService extends javax.xml.rpc.Service {
    public java.lang.String getUpdateUserSEIPortAddress();

    public com.atg.www.webservices.UpdateUserSEI getUpdateUserSEIPort() throws javax.xml.rpc.ServiceException;

    public com.atg.www.webservices.UpdateUserSEI getUpdateUserSEIPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
